use jomato

select * from jomato

CREATE PROCEDURE GetRestaurantsWithBookings
AS
BEGIN
    SELECT 
        RestaurantName, CuisinesType
            FROM  jomato
    WHERE 
        TableBooking > 0;
END;

EXEC GetRestaurantsWithBookings;

2
BEGIN TRANSACTION
-- Update cuisine type from 'Cafe' to 'Cafeteria'
UPDATE jomato 
SET CuisinesType = 'Cafeteria'
WHERE CuisinesType = 'Cafe'

-- Check the result
SELECT * FROM jomato WHERE CuisinesType ='Cafeteria'

-- Rollback the transaction
ROLLBACK;

-- Check the result after rollback
SELECT * FROM jomato  WHERE CuisinesType�='Cafe'


 3.
WITH max_ratings AS (
    select restaurantname,restauranttype,rating, area,ROW_NUMBER() over (order by rating desc) as max_ratings from jomato 
)
SELECT restaurantname,restauranttype,rating, area
FROM  max_ratings
WHERE max_ratings <= 5
ORDER BY�max_ratings�asc;

4
DECLARE @i INT = 1;

WHILE @i <= 50
BEGIN
    PRINT @i;
    SET @i = @i + 1;
END;

5
CREATE VIEW TopRatingView AS
SELECT RestaurantName,Rating 
FROM 
    (SELECT RestaurantName, Rating,
        ROW_NUMBER() OVER (ORDER BY Rating DESC) AS RowNum
     FROM jomato
    ) AS TopRatings
WHERE RowNum <= 5;

SELECT * FROM TopRatingView;

6

create trigger dbo.restaurant_insert
       on dbo.jomato
after insert
as
begin
       set nocount on;
       declare @orderid int
       select @orderid = inserted.orderid      
       from inserted
       declare @body varchar(500) = 'restaurant with id: ' + cast(@orderid as varchar(5)) + ' inserted.'
       exec msdb.dbo.sp_send_dbmail
            @profile_name = 'data analyst batch 18'
           ,@recipients = 'swatisingh24012003@gmail.com'
           ,@subject = 'new restaurant record'
           ,@body = @body
           ,@importance�='high'
end


